package com.example.aliexpress;

import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ChatMessageViewHolder extends RecyclerView.ViewHolder {
    TextView tvSenderName, tvMessage, tvTimestamp;

    public ChatMessageViewHolder(@NonNull View itemView) {
        super(itemView);
        tvSenderName = itemView.findViewById(R.id.tvSenderName);
        tvMessage = itemView.findViewById(R.id.tvMessage);
        tvTimestamp = itemView.findViewById(R.id.tvTimestamp);
    }

    public void bind(ChatMessage message) {
        tvMessage.setText(message.message);
        tvSenderName.setText(message.senderName);
        tvTimestamp.setText(DateUtils.getRelativeTimeSpanString(message.timestamp));
    }
}
