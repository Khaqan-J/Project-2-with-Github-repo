package com.example.aliexpress;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.*;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.IOException;

public class ObjectDetectionActivity extends AppCompatActivity {
    private TextView tvResult;
    private final OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_object_detection);

        tvResult = findViewById(R.id.tvResult);
        Button btnDetect = findViewById(R.id.btnDetect);

        btnDetect.setOnClickListener(v -> detectObjects());
    }

    private void detectObjects() {
        // Use demo image URL or camera image
        String imageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/YOLOv4results.jpg/800px-YOLOv4results.jpg";

        String json = "{\"inputs\":\"" + imageUrl + "\"}";
        RequestBody body = RequestBody.create(json, MediaType.parse("application/json"));

        Request request = new Request.Builder()
                .url("https://hf.space/embed/yolo-detection/YOLOv8/+/api/predict/")
                .post(body)
                .addHeader("Authorization", "Bearer YOUR_HF_TOKEN") // Replace with actual token if needed
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                runOnUiThread(() -> Toast.makeText(ObjectDetectionActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                try (ResponseBody responseBody = response.body()) {
                    if (response.isSuccessful() && responseBody != null) {
                        String result = responseBody.string();
                        runOnUiThread(() -> tvResult.setText("Detected: " + parseYoloResult(result)));
                    } else {
                        runOnUiThread(() -> tvResult.setText("Server Error: " + response.code()));
                    }
                }
            }
        });
    }

    /**
     * Parses the JSON response from the YOLO API.
     */
    private String parseYoloResult(String json) {
        if (json == null || json.isEmpty()) return "Empty response";
        try {
            JsonObject root = new Gson().fromJson(json, JsonObject.class);
            if (root.has("data")) {
                return root.get("data").toString();
            }
            return json; // Return raw JSON if "data" field is missing
        } catch (Exception e) {
            return "Error parsing response: " + e.getMessage();
        }
    }
}
