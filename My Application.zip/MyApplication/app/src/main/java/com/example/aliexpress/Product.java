package com.example.aliexpress;

public class Product {
    private String name;
    private String price;
    private String rating;
    private String sold;

    public Product(String name, String price, String rating, String sold) {
        this.name = name;
        this.price = price;
        this.rating = rating;
        this.sold = sold;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }

    public String getRating() {
        return rating;
    }

    public String getSold() {
        return sold;
    }
}
