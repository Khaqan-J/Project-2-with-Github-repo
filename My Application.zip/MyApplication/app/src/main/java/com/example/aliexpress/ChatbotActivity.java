package com.example.aliexpress;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ChatbotActivity extends AppCompatActivity {

    private TextView tvChatHistory;
    private EditText etUserMessage;
    private Button btnSend;

    private OkHttpClient client = new OkHttpClient();
    private Gson gson = new Gson();

    // Replace with BuildConfig field (see below)
    private static final String GEMINI_API_KEY = BuildConfig.GEMINI_API_KEY;

    private static final String GEMINI_ENDPOINT =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

    private StringBuilder historyBuilder = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatbot);

        tvChatHistory = findViewById(R.id.tvChatHistory);
        etUserMessage = findViewById(R.id.etUserMessage);
        btnSend = findViewById(R.id.btnSend);

        addSystemMessage(
                "You are a helpful assistant **inside an AliExpress-style shopping app clone**. " +
                        "Only answer questions related to:\n" +
                        "- this app's screens (splash, signup, login, products, drawer, QR scanner, fragments, data input/display)\n" +
                        "- how to use the app, login, signup, reset password, scan QR codes, view products, navigate screens.\n" +
                        "Use short, clear answers. If the question is not related to this app, say: " +
                        "\"I can only help with this AliExpress clone app.\""
        );

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userText = etUserMessage.getText().toString().trim();
                if (userText.isEmpty()) {
                    return;
                }
                appendToHistory("You: " + userText + "\n\n");
                etUserMessage.setText("");
                sendToGemini(userText);
            }
        });
    }

    private void addSystemMessage(String msg) {
        appendToHistory("Assistant (system): " + msg + "\n\n");
    }

    private void appendToHistory(String text) {
        historyBuilder.append(text);
        tvChatHistory.setText(historyBuilder.toString());
    }

    private void sendToGemini(String userMessage) {
        btnSend.setEnabled(false);

        // Build prompt with some history to “tokenize” context around app type
        String prompt =
                "You are embedded in an Android AliExpress clone app. " +
                        "Conversation so far:\n\n" + historyBuilder.toString() +
                        "\nUser question:\n" + userMessage;

        new Thread(() -> {
            try {
                String answer = callGeminiApi(prompt);
                runOnUiThread(() -> {
                    appendToHistory("Assistant: " + answer + "\n\n");
                    btnSend.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(ChatbotActivity.this,
                            "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    btnSend.setEnabled(true);
                });
            }
        }).start();
    }

    private String callGeminiApi(String promptText) throws IOException {
        JsonObject textPart = new JsonObject();
        textPart.addProperty("text", promptText);

        JsonArray parts = new JsonArray();
        parts.add(textPart);

        JsonObject content = new JsonObject();
        content.add("parts", parts);

        JsonArray contents = new JsonArray();
        contents.add(content);

        JsonObject requestBodyJson = new JsonObject();
        requestBodyJson.add("contents", contents);

        MediaType jsonMediaType = MediaType.parse("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(jsonMediaType, gson.toJson(requestBodyJson));

        Request request = new Request.Builder()
                .url(GEMINI_ENDPOINT + "?key=" + GEMINI_API_KEY)
                .post(body)
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("HTTP error " + response.code() + ": " + response.message());
            }

            String responseString = response.body().string();
            JsonObject root = gson.fromJson(responseString, JsonObject.class);

            JsonArray candidates = root.getAsJsonArray("candidates");
            if (candidates == null || candidates.size() == 0) {
                return "No response from AI.";
            }

            JsonObject firstCandidate = candidates.get(0).getAsJsonObject();
            JsonObject firstContent = firstCandidate
                    .getAsJsonObject("content");

            JsonArray responseParts = firstContent.getAsJsonArray("parts");
            if (responseParts == null || responseParts.size() == 0) {
                return "No text in AI response.";
            }

            JsonObject firstPart = responseParts.get(0).getAsJsonObject();
            return firstPart.get("text").getAsString();
        }
    }
}
