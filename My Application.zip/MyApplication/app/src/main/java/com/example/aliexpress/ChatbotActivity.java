package com.example.aliexpress;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.ChatFutures;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.ai.client.generativeai.type.GenerationConfig;
import com.google.ai.client.generativeai.type.RequestOptions;
import com.google.android.material.button.MaterialButton;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ChatbotActivity extends AppCompatActivity {

    private static final String TAG = "ChatbotActivity";
    private TextView tvChatHistory;
    private EditText etUserMessage;
    private MaterialButton btnSend;
    private ScrollView chatScrollView;

    private ChatFutures chatHistory;
    private StringBuilder historyDisplay = new StringBuilder();
    private final Executor executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatbot);

        tvChatHistory = findViewById(R.id.tvChatHistory);
        etUserMessage = findViewById(R.id.etUserMessage);
        btnSend = findViewById(R.id.btnSend);
        chatScrollView = findViewById(R.id.chatScrollView);

        String apiKey = BuildConfig.GEMINI_API_KEY;

        if (apiKey == null || apiKey.trim().isEmpty()) {
            Toast.makeText(this, "Error: Gemini API Key is missing. Add it to local.properties", Toast.LENGTH_LONG).show();
            btnSend.setEnabled(false);
            return;
        }

        try {
            // Setup System Instruction
            Content systemInstruction = new Content.Builder()
                    .addText("You are a helpful multilingual assistant for the AliExpress app. " +
                            "Respond in the user's language. Keep answers short and helpful.")
                    .build();

            // Use the simplest working configuration to avoid version mismatches
            GenerativeModel gm = new GenerativeModel(
                    "gemini-1.5-flash",
                    apiKey,
                    new GenerationConfig.Builder().build(),
                    null, // safetySettings
                    new RequestOptions(), 
                    null, // tools
                    null, // toolConfig
                    systemInstruction
            );
            
            GenerativeModelFutures model = GenerativeModelFutures.from(gm);
            chatHistory = model.startChat();

            appendToDisplay("🤖 Assistant: Hello! How can I help you today?\n\n");

        } catch (Exception e) {
            Log.e(TAG, "Initialization failed", e);
            Toast.makeText(this, "Chatbot failed to start. Please check your API key.", Toast.LENGTH_LONG).show();
            btnSend.setEnabled(false);
        }

        btnSend.setOnClickListener(v -> {
            String userText = etUserMessage.getText().toString().trim();
            if (!userText.isEmpty()) {
                sendMessage(userText);
            }
        });
    }

    private void sendMessage(String userText) {
        if (chatHistory == null) return;

        appendToDisplay("You: " + userText + "\n\n");
        etUserMessage.setText("");
        btnSend.setEnabled(false);

        Content userMessage = new Content.Builder()
                .addText(userText)
                .build();

        try {
            ListenableFuture<GenerateContentResponse> response = chatHistory.sendMessage(userMessage);

            Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
                @Override
                public void onSuccess(GenerateContentResponse result) {
                    String botResponse = result.getText();
                    runOnUiThread(() -> {
                        if (botResponse != null && !botResponse.isEmpty()) {
                            appendToDisplay("Assistant: " + botResponse + "\n\n");
                        } else {
                            appendToDisplay("Assistant: [Sorry, I couldn't generate a response.]\n\n");
                        }
                        btnSend.setEnabled(true);
                    });
                }

                @Override
                public void onFailure(Throwable t) {
                    Log.e(TAG, "Gemini error", t);
                    runOnUiThread(() -> {
                        String error = t.getMessage();
                        if (error != null && error.contains("404")) {
                            error = "Model not found. Ensure your API Key has access to Gemini 1.5 Flash.";
                        }
                        appendToDisplay("Assistant: [Error: " + error + "]\n\n");
                        btnSend.setEnabled(true);
                    });
                }
            }, executor);
        } catch (Exception e) {
            Log.e(TAG, "Send failed", e);
            btnSend.setEnabled(true);
        }
    }

    private void appendToDisplay(String text) {
        historyDisplay.append(text);
        tvChatHistory.setText(historyDisplay.toString());
        chatScrollView.post(() -> chatScrollView.fullScroll(View.FOCUS_DOWN));
    }
}
