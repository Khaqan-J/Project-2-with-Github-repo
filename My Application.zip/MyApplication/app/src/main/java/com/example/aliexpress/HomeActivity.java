package com.example.aliexpress;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProductAdapter productAdapter;
    private List<Product> productList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        productList = getProducts();
        productAdapter = new ProductAdapter(this, productList);
        recyclerView.setAdapter(productAdapter);
    }

    private List<Product> getProducts() {
        List<Product> products = new ArrayList<>();
        products.add(new Product("Screwdriver Set", "PKR 758", "4.6", "10,000+ sold"));
        products.add(new Product("Tool Kit", "PKR 5,010", "4.3", "10,000+ sold"));
        products.add(new Product("Hair Dryer", "PKR 504", "4.5", "10,000+ sold"));
        products.add(new Product("Wireless CarPlay", "PKR 4,496", "4.7", "5,000+ sold"));
        products.add(new Product("Stitch Toy", "PKR 1,036", "4.8", "15,000+ sold"));
        products.add(new Product("Water Bottle", "PKR 1,660", "4.4", "8,000+ sold"));
        products.add(new Product("LED Lights", "PKR 2,300", "4.5", "12,000+ sold"));
        products.add(new Product("Phone Case", "PKR 450", "4.2", "20,000+ sold"));
        products.add(new Product("Bluetooth Speaker", "PKR 3,200", "4.6", "7,000+ sold"));
        products.add(new Product("Smart Watch", "PKR 5,500", "4.4", "9,000+ sold"));
        return products;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_qr_scanner) {
            startActivity(new Intent(HomeActivity.this, QRScannerActivity.class));
            return true;
        } else if (id == R.id.action_chatbot) {
            startActivity(new Intent(HomeActivity.this, ChatbotActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
