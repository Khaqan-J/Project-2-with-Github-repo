package com.example.aliexpress;

public class ChatMessage {
    public String message;
    public String senderId;
    public String senderName;
    public long timestamp;

    public ChatMessage() {} // Firebase needs empty constructor

    public ChatMessage(String message, String senderId, String senderName) {
        this.message = message;
        this.senderId = senderId;
        this.senderName = senderName;
        this.timestamp = System.currentTimeMillis();
    }
}
