package com.example.aliexpress;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class DataDisplayActivity extends AppCompatActivity {

    private TextView tvDisplayUsername, tvDisplayAge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        tvDisplayUsername = findViewById(R.id.tvDisplayUsername);
        tvDisplayAge = findViewById(R.id.tvDisplayAge);

        String username = getIntent().getStringExtra("username");
        long dobMillis = getIntent().getLongExtra("dobMillis", 0);

        int age = calculateAge(dobMillis);

        tvDisplayUsername.setText("Username: " + username);
        tvDisplayAge.setText("Age: " + age + " years");
    }

    private int calculateAge(long dobMillis) {
        Calendar dob = Calendar.getInstance();
        dob.setTimeInMillis(dobMillis);

        Calendar today = Calendar.getInstance();

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
            age--;
        }

        return age;
    }
}
